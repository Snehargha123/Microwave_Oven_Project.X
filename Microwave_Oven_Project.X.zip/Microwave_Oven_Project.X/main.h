/* 
 * File:   main.h
 * Author: USER
 *
 * Created on 12 June, 2026, 5:18 PM
 */

#ifndef MAIN_H        // <-- ADDED THIS LINE
#define MAIN_H        // <-- ADDED THIS LINE

#include "matrix_keypad.h"
#include "timer.h"
#include <xc.h>

#define POWER_ON_SCREEN  0x01
#define MENU_SCREEN      0x02
#define MICRO_MODE       0x11
#define GRILL_MODE       0x12
#define CONVECTION_MODE  0x13
#define START_MODE       0x14
// Convection-specific sub-states
#define CONV_TEMP_SCREEN 0x15
#define PREHEAT_SCREEN   0x16
#define RESET_NOTHING    0x00 
#define RESET_MODE       0xFF
#define DISPLAY_TIME     0xDD


#define START            0xAA
#define STOP             0xBB
#define PAUSE            0xCC


#define FAN_DDR          TRISC2
#define FAN               RC2

#define BUZZER_DDR       TRISC1
#define BUZZER            RC1
#endif /* MAIN_H */

