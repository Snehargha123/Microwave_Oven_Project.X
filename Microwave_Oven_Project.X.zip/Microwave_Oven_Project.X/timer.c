#include <xc.h>
#include "timer.h"

void init_timer0(void)
{
    /* Setting the internal clock source */
    T0CS = 0;
    
    /* Assigning the pre-scaler to Watchdog Timer */
    PSA = 1;

    TMR0 = 6;
    
    /* The timer interrupt is enabled */
    TMR0IE = 1;
}
