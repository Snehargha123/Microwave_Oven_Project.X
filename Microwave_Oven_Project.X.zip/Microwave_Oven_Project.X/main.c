

#include <xc.h>
#include "clcd.h"
#include "main.h"
#include "matrix_keypad.h"
#include "timer.h"

#pragma config WDTE = OFF   

unsigned char time_buf[4] = {'0', '0', '0', '0'};

unsigned char operation_mode = POWER_ON_SCREEN;
unsigned char cooking_status = START;
unsigned char minutes = 0;
unsigned char seconds = 0;
unsigned int convection_temp = 0;
unsigned int preheat_seconds = 60; 


void power_on(void)
{
    clcd_print("  POWERING ON   ", LINE1(0));
    clcd_print(" MICROWAVE OVEN ", LINE2(0));
    clcd_print("   PLEASE WAIT  ", LINE3(0));
    clcd_print("   RESETTING    ", LINE4(0));
    
    __delay_ms(2000);
    clcd_clear_screen();
    operation_mode = MENU_SCREEN; // Move to menu selection screen
}

void set_temp_screen(unsigned char key)
{
    clcd_print(" SET TEMP (degC)", LINE1(0));
    clcd_print(" TEMP: ", LINE2(0));
    
    // Display dynamic three-digit temperature
    clcd_putch((convection_temp / 100) + '0', LINE2(7));
    clcd_putch(((convection_temp % 100) / 10) + '0', LINE2(8));
    clcd_putch((convection_temp % 10) + '0', LINE2(9));
    
    clcd_print("*:CLEAR   #:CONF", LINE4(0));

    if (key != ALL_RELEASED)
    {
        if (key >= 0 && key <= 9)
        {
            // Allow digit entry up to a maximum safety limit (e.g., 250 degrees)
            if (convection_temp < 180) 
            {
                convection_temp = (convection_temp * 10) + key;
                if (convection_temp > 180) 
                    convection_temp = 180; 
            }
        }
        else if (key == '*')
        {
            convection_temp = 0; // Clear entry
        }
        else if (key == '#') // Confirm Temperature
        {
            if (convection_temp > 0)
            {
                clcd_clear_screen();
                preheat_seconds = 60; // Automatically load 1 minute
                FAN = 1;               // Turn on heating fan for preheat
                operation_mode = PREHEAT_SCREEN; // Advance to Preheat!
            }
        }
    }
}

void run_preheat(void)
{
    clcd_print("   PREHEATING   ", LINE1(0));
    clcd_print(" TEMP IS RISING ", LINE2(0));
    clcd_print(" TIME REM:      ", LINE3(0));
    
    // Display standard MM:SS format derived from total seconds
    clcd_putch((preheat_seconds / 60) + '0', LINE3(11));
    clcd_putch(':', LINE3(12));
    clcd_putch(((preheat_seconds % 60) / 10) + '0', LINE3(13));
    clcd_putch(((preheat_seconds % 60) % 10) + '0', LINE3(14));

    __delay_ms(1000); // 1-second dynamic tick
    
    if (preheat_seconds > 0)
    {
        preheat_seconds--;
    }
    else
    {
        // Preheat reaches 0! Sound a short alert beep
        BUZZER = 1;
        __delay_ms(500);
        BUZZER = 0;
        
        clcd_clear_screen();
        
        // Advance to the Set Time Screen under Convection Mode
        operation_mode = CONVECTION_MODE; 
    }
}



void run_cooking_mode(unsigned char key)
{
    clcd_print("TIME =   ", LINE1(0));
    clcd_putch((minutes / 10) + '0', LINE1(9));
    clcd_putch((minutes % 10) + '0', LINE1(10));
    clcd_putch(':', LINE1(11));
    clcd_putch((seconds / 10) + '0', LINE1(12));
    clcd_putch((seconds % 10) + '0', LINE1(13));
    
    clcd_print("  4.START/RESUME", LINE2(0));
    clcd_print("  5.PAUSE", LINE3(0));
    clcd_print("  6.STOP", LINE4(0));

    if (key != ALL_RELEASED)
    {
        if (key == 4)
        {
            cooking_status = START;
            FAN = 1;
        }
        else if (key == 5)
        {
            cooking_status = PAUSE;
            FAN = 0;
        }
        else if (key == 6)
        {
            FAN = 0;
            clcd_clear_screen();
            operation_mode = MENU_SCREEN;
            return;
        }
    }

    if (cooking_status == START)
    {
        __delay_ms(1000);
        if (seconds > 0)
        {
            seconds--;
        }
        else if (minutes > 0)
        {
            minutes--;
            seconds = 59;
        }
        
        if (minutes == 0 && seconds == 0)
        {
            FAN = 0;
            clcd_clear_screen();
            clcd_print(" COOKING DONE!  ", LINE2(0));
            BUZZER = 1;
            __delay_ms(2000);
            BUZZER = 0;
            clcd_clear_screen();
            operation_mode = MENU_SCREEN;
        }
    }
}

void set_time_screen(unsigned char key)
{
    static unsigned char index = 0;

    clcd_print(" SET COOK TIME ", LINE1(0));

    clcd_putch(time_buf[0], LINE2(5));
    clcd_putch(time_buf[1], LINE2(6));
    clcd_putch(':',        LINE2(7));
    clcd_putch(time_buf[2], LINE2(8));
    clcd_putch(time_buf[3], LINE2(9));

    clcd_print("*:CLR  #:START", LINE4(0));

    if(key != ALL_RELEASED)
    {
        /* Numeric key pressed */
        if(key <= 9)
        {
            if(index < 4)
            {
                time_buf[index] = key + '0';
                index++;
            }
        }

        /* Clear Entry */
        else if(key == '*')
        {
            index = 0;

            time_buf[0]='0';
            time_buf[1]='0';
            time_buf[2]='0';
            time_buf[3]='0';
        }

        /* Start Cooking */
        else if(key == '#')
        {
            minutes =
                    (time_buf[0]-'0')*10 +
                    (time_buf[1]-'0');

            seconds =
                    (time_buf[2]-'0')*10 +
                    (time_buf[3]-'0');

            if (minutes > 0 || seconds > 0)
            {
                clcd_clear_screen();
                FAN = 1;                         // Turn on Fan
                cooking_status = START;  // Start countdown immediately
                operation_mode = START_MODE;     // Go to Run Mode screen
            }
        }
    }
}


void main_menu(unsigned char key)
{
    /* With a 16x4 display, we can cleanly display one mode per line! */
    clcd_print("1. Micro        ", LINE1(0));
    clcd_print("2. Grill        ", LINE2(0));
    clcd_print("3. Convection   ", LINE3(0));
    clcd_print("4. Start        ", LINE4(0));
    
    if (key == 1)      // Matrix keypad key 1 pressed
    {
        clcd_clear_screen();
        operation_mode = MICRO_MODE;
    }
    else if (key == 2) // Key 2 pressed
    {
        clcd_clear_screen();
        operation_mode = GRILL_MODE;
    }
    else if (key == 3) // Key 3 pressed
    {
        clcd_clear_screen();
        operation_mode = CONV_TEMP_SCREEN;;
    }
}



void display(unsigned char key)
{
    switch (operation_mode) 
    {
        case POWER_ON_SCREEN:
            power_on();
            break;
            
        case MENU_SCREEN:
            main_menu(key);
            break;
            
        case MICRO_MODE:
        case GRILL_MODE:
        case CONVECTION_MODE:
         
            set_time_screen(key);
            break;
            
        case CONV_TEMP_SCREEN:
            set_temp_screen(key);
            break;
            
        case PREHEAT_SCREEN:
            run_preheat();
            break;
            
        case START_MODE:
            run_cooking_mode(key);
            break;
            
        default:
            break;
    }
}

void init_config(void) {
    // Hardware direction settings
    FAN_DDR = 0;
    BUZZER_DDR = 0;
    FAN = 0;
    BUZZER = 0;
    
    init_clcd();
    init_matrix_keypad();
}

void main(void) {
    unsigned char key;
    
    init_config();

    while (1) {
        // Read key (EDGE trigger mode works best for one-click menu transitions)
        key = read_matrix_keypad(STATE);  
        display(key);
    }
}

